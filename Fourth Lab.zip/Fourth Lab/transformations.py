
from PIL import Image, ImageOps, ImageEnhance

def transform_images(input_path):
    """
    Applies various transformations to an input image and saves the results.
    """
    try:
        # Open the input image
        with Image.open(input_path) as img:
            # Ensure image is in a suitable mode (e.g., 'L' for grayscale, 'RGB' for color)
            # The provided image is grayscale, so let's work with that.
            if img.mode != 'L':
                img = img.convert('L')

            # --- Result1: Color Inversion ---
            img_result1 = ImageOps.invert(img)
            img_result1.save("Result1_generated.png")

            # --- Result2: Increased Contrast (Refined) ---
            # Using ImageEnhance.Contrast for more control
            contrast_enhancer = ImageEnhance.Contrast(img)
            img_result2 = contrast_enhancer.enhance(2.0)
            img_result2.save("Result2_generated.png")

            # --- Result3: Increased Gamma (Brighter - Refined) ---
            # A gamma < 1.0 makes the image brighter. Let's try 0.4
            gamma_brighter = 0.4
            img_result3 = img.point(lambda x: 255 * ((x / 255) ** gamma_brighter))
            img_result3.save("Result3_generated.png")

            # --- Result4: Decreased Gamma (Darker - Refined) ---
            # A gamma > 1.0 makes the image darker. Let's try 2.2
            gamma_darker = 2.2
            img_result4 = img.point(lambda x: 255 * ((x / 255) ** gamma_darker))
            img_result4.save("Result4_generated.png")

            print("All transformations have been applied and saved (v2).")

    except FileNotFoundError:
        print(f"Error: The file '{input_path}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    transform_images("input.png")
